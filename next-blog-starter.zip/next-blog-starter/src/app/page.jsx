import styles from "./homepage.module.css";

export default function Home() {
  return <div>Hello</div>;
}
